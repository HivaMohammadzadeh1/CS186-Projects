# Project 1: SQL

This project is due on **Friday, 9/9/2022 at 11:59PM PDT (GMT-7)**. Follow the instructions [here](https://cs186.gitbook.io/project/assignments/proj1) to get started.
