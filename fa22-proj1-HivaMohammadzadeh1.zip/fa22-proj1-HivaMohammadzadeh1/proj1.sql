-- Before running drop any existing views
DROP VIEW IF EXISTS q0;
DROP VIEW IF EXISTS q1i;
DROP VIEW IF EXISTS q1ii;
DROP VIEW IF EXISTS q1iii;
DROP VIEW IF EXISTS q1iv;
DROP VIEW IF EXISTS q2i;
DROP VIEW IF EXISTS q2ii;
DROP VIEW IF EXISTS q2iii;
DROP VIEW IF EXISTS q3i;
DROP VIEW IF EXISTS q3ii;
DROP VIEW IF EXISTS q3iii;
DROP VIEW IF EXISTS q4i;
DROP VIEW IF EXISTS q4ii;
DROP VIEW IF EXISTS q4iii;
DROP VIEW IF EXISTS q4iv;
DROP VIEW IF EXISTS q4v;

-- Question 0
CREATE VIEW q0(era)
AS
  SELECT Max(era)
  FROM pitching 
;

-- Question 1i
CREATE VIEW q1i(namefirst, namelast, birthyear)
AS
  SELECT namefirst, namelast, birthyear
  FROM people
  WHERE weight > 300
;

-- Question 1ii
CREATE VIEW q1ii(namefirst, namelast, birthyear)
AS
  SELECT namefirst, namelast, birthyear
  FROM people
  WHERE namefirst LIKE '% %'
  ORDER BY namefirst ASC, namelast ASC
;

-- Question 1iii
CREATE VIEW q1iii(birthyear, avgheight, count)
AS
  SELECT birthyear, AVG(height) AS avgheight, COUNT(*) AS count 
  FROM people 
  GROUP BY birthyear 
  ORDER BY birthyear ASC 
;

-- Question 1iv
CREATE VIEW q1iv(birthyear, avgheight, count)
AS
  SELECT birthyear, AVG(height) AS avgheight, COUNT(*) AS count
  FROM people
  GROUP BY birthyear
  HAVING avg(height) > 70
  ORDER BY birthyear ASC
;

-- Question 2i
CREATE VIEW q2i(namefirst, namelast, playerid, yearid)
AS
  SELECT P.namefirst AS namefirst, P.namelast AS namelast, H.playerid AS playerid, H.yearid AS yearid
  FROM HallOfFame AS H INNER JOIN people AS P ON H.playerid = P.playerid
  WHERE H.inducted = 'Y'
  ORDER BY H.yearid DESC, H.playerid ASC 
;

-- Question 2ii
CREATE VIEW q2ii(namefirst, namelast, playerid, schoolid, yearid)
AS
  SELECT P.namefirst AS namefirst, P.namelast AS namelast, H.playerid AS playerid, S.schoolid AS playerid, H.yearid AS yearid
  FROM HallOfFame AS H INNER JOIN people AS P ON H.playerid = P.playerid INNER JOIN CollegePlaying AS C ON C.playerid = P.playerid INNER JOIN Schools AS S ON S.schoolid = C.schoolid
  WHERE H.inducted = 'Y' AND S.schoolState = 'CA' 
  ORDER BY H.yearid DESC, S.schoolid, H.playerid ASC  
                  
;

-- Question 2iii
CREATE VIEW q2iii(playerid, namefirst, namelast, schoolid)
AS
  SELECT H.playerid AS playerid, P.namefirst AS namefirst, P.namelast AS namelast, S.schoolid AS schoolid
  FROM hallOfFame AS H INNER JOIN people AS P ON H.playerid = P.playerid LEFT OUTER JOIN CollegePlaying AS C ON C.playerid = P.playerid LEFT OUTER JOIN schools AS S ON S.schoolid = C.schoolid
  WHERE H.inducted = 'Y'
  ORDER BY H.playerid DESC, H.playerid, S.schoolid ASC
;

-- Question 3i
CREATE VIEW q3i(playerid, namefirst, namelast, yearid, slg)
AS
  SELECT P.playerid AS playerid, P.namefirst AS namefirst, P.namelast AS namelast, B.yearid AS yearid, (B.H - B.H2B - B.H3B - B.HR + 2 * B.H2B + 3 * B.H3B + 4 * B.HR) / (cast(B.AB as real)) AS slg
  FROM people AS P INNER JOIN Batting as B ON P.playerid = B.playerid
  WHERE B.AB > 50
  ORDER BY slg DESC, B.yearid, P.playerid ASC
  LIMIT 10
;

-- Question 3ii
CREATE VIEW q3ii(playerid, namefirst, namelast, lslg)
AS
  SELECT P.playerid AS playerid, P.namefirst AS namefirst, P.namelast AS namelast, SUM(B.H - B.H2B - B.H3B - B.HR + 2 * B.H2B + 3 * B.H3B + 4 * B.HR) / (cast(SUM(B.AB) as real)) as lslg
  FROM people as P INNER JOIN Batting as B on B.playerid = P.playerid
  WHERE B.AB > 0
  GROUP BY P.playerid
  HAVING(SUM(B.AB) > 50)
  ORDER BY lslg DESC, P.playerid ASC
  LIMIT 10
;

-- Question 3iii
CREATE VIEW q3iii(namefirst, namelast, lslg)
AS
  WITH A AS (
	SELECT P.playerid, SUM(B.H - B.H2B - B.H3B - B.HR + 2*B.H2B + 3*B.H3B + 4*B.HR) / (cast(SUM(B.AB) as real)) as lslg
        FROM people as P INNER JOIN Batting as B on B.playerid = P.playerid
        WHERE B.AB > 0
        GROUP BY P.playerid
        HAVING(SUM(B.AB) > 50))

  SELECT P.namefirst AS namefirst, P.namelast AS namelast, a.lslg
  FROM people AS P INNER JOIN A AS a ON P.playerid = a.playerid
  WHERE a.lslg > (SELECT lslg FROM a WHERE playerid = 'mayswi01')
  
;

-- Question 4i
CREATE VIEW q4i(yearid, min, max, avg)
AS
  SELECT S.yearid AS yearid, MIN(S.salary) AS min, MAX(S.salary) AS max, AVG(S.salary) AS avg
  FROM Salaries AS S
  GROUP BY yearid
  ORDER BY yearid ASC
;

-- Question 4ii
CREATE VIEW q4ii(binid, low, high, count)
AS
  SELECT binid, 507500.0 + binid * 3249250 AS low, 3756750.0 + binid * 3249250 AS high, count(*)
  from binids,salaries AS S
  where (S.salary between 507500.0 + binid * 3249250 and 3756750.0 + binid * 3249250) and yearID='2016'
  group by binid
;


-- Question 4iii
CREATE VIEW q4iii(yearid, mindiff, maxdiff, avgdiff)
AS
  WITH previousYear AS (   
  SELECT (S.yearid + 1) AS newYearid, MIN(S.salary) as min, MAX(S.salary) as max, AVG(S.salary) as avg
  FROM Salaries AS S 
  GROUP BY newYearid
),
  currentYear AS (
    SELECT S.yearid, MIN(S.salary) AS min, MAX(S.salary) AS max, AVG(S.salary) as avg
    FROM Salaries AS S 
    GROUP BY yearid
)
 SELECT C.yearid, (C.min - p.min) AS mindiff, (C.max - P.max) AS maxdiff, (C.avg - P.avg) AS avgdiff
 FROM previousYear AS P INNER JOIN currentYear AS C ON P.newYearid = C.yearid
 ORDER BY C.yearid
;

-- Question 4iv
CREATE VIEW q4iv(playerid, namefirst, namelast, salary, yearid)
AS
  SELECT S.playerid, P.namefirst, P.namelast, S.salary, S.yearid
  FROM salaries AS S INNER JOIN people AS P ON  S.playerid = P.playerid
  WHERE S.yearid = 2000 and S.salary = (SELECT MAX(S2.salary) FROM salaries AS S2 WHERE S2.yearid = 2000)

UNION

  SELECT S.playerid AS playerid, P.namefirst AS namefirst, P.namelast AS namelast, S.salary AS salary, S.yearid AS yearid
  FROM salaries AS S INNER JOIN people AS P ON S.playerid = P.playerid
  WHERE S.yearid = 2001 and S.salary = (SELECT MAX(S2.salary) FROM salaries AS S2 WHERE S2.yearid = 2001) 
;

-- Question 4v
CREATE VIEW q4v(team, diffAvg) AS
  SELECT A.teamid AS team, MAX(S.salary) -  MIN(S.salary) AS diffAvg 
  FROM AllStarFull AS A INNER JOIN Salaries AS S ON A.playerid = S.playerid AND A.yearid = S.yearid 
  WHERE S.yearid = 2016
  GROUP BY A.teamid
;

