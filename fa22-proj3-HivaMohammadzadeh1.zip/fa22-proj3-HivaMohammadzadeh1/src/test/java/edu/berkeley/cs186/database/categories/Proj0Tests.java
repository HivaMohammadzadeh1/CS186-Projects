package edu.berkeley.cs186.database.categories;

public interface Proj0Tests extends ProjTests  { /* category marker */ }